import { ButtonLink } from '@/components/ButtonLink'
import { Card } from '@/components/Card'
import { Section } from '@/components/Section'

const sections = [
  {
    title: 'Memberships',
    eyebrow: 'Access',
    items: [
      {
        title: 'Odyssey Membership',
        text: 'Programming, collaborations, and entry into the Odyssey ecosystem. No pricing shown here yet.'
      }
    ]
  },
  {
    title: 'Programs',
    eyebrow: 'Library',
    items: [
      {
        title: 'Mobility & Regulation',
        text: 'Flows and protocols built for longevity, range, and nervous-system balance.'
      },
      {
        title: 'Performance Foundations',
        text: 'Strength and mechanics built to hold up when the pace gets real.'
      }
    ]
  },
  {
    title: 'Merchandise',
    eyebrow: 'Coming soon',
    items: [
      {
        title: 'Odyssey Goods',
        text: 'Apparel and training gear. Limited drops over time. Visible now, releasing soon.'
      }
    ]
  }
]

export default function MarketplacePage() {
  return (
    <>
      <Section kicker="Marketplace" title="Choose your lane. Keep your pace.">
        <div className="max-w-3xl text-sm leading-6 text-ink-900/80">
          Nothing here is priced publicly yet. If you want in, request access and we’ll place you where you fit.
        </div>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <ButtonLink href="/request-access" variant="primary">
            Request Access
          </ButtonLink>
          <ButtonLink href="/consult" variant="secondary">
            Book a Free Consult
          </ButtonLink>
        </div>
      </Section>

      {sections.map((s) => (
        <Section key={s.title} kicker={s.eyebrow} title={s.title}>
          <div className="grid gap-5 md:grid-cols-2">
            {s.items.map((i) => (
              <Card
                key={i.title}
                title={i.title}
                footer={
                  <div className="flex items-center gap-3">
                    <ButtonLink href="/request-access" variant="primary">
                      Request Access
                    </ButtonLink>
                    <ButtonLink href="/consult" variant="secondary">
                      Book Consult
                    </ButtonLink>
                  </div>
                }
              >
                {i.text}
              </Card>
            ))}
          </div>
        </Section>
      ))}
    </>
  )
}
