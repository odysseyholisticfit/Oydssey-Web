import { ButtonLink } from '@/components/ButtonLink'
import { Card } from '@/components/Card'
import { Section } from '@/components/Section'
import { collaborations } from '@/lib/site'

export default function MissionPage() {
  return (
    <>
      <Section kicker="Mission" title="Odyssey exists to restore connection.">
        <div className="max-w-3xl space-y-4 text-sm leading-7 text-ink-900/80">
          <p>
            Odyssey is built for people who want more than intensity. We train with purpose, regulate the nervous system,
            and build longevity through consistent, disciplined practice.
          </p>
          <p>
            We believe strength is not rushed, performance is not forced, and the real edge is earned through awareness.
            Connection to self comes first — then connection to the people around you.
          </p>
        </div>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <ButtonLink href="/request-access" variant="primary">
            Request Access
          </ButtonLink>
          <ButtonLink href="/consult" variant="secondary">
            Book a Free Consult
          </ButtonLink>
        </div>
      </Section>

      <Section kicker="Philosophy" title="Regulation before intensity.">
        <div className="grid gap-5 md:grid-cols-3">
          <Card title="Movement as medicine" eyebrow="Principle I">
            Mobility, strength, and breath stitched together — so the body feels like home again.
          </Card>
          <Card title="Sustainable pace" eyebrow="Principle II">
            We train the long game: joints, tissue quality, and consistency that doesn’t break you.
          </Card>
          <Card title="Community over isolation" eyebrow="Principle III">
            Collaboration is the multiplier. We build with people who align with the mission.
          </Card>
        </div>
      </Section>

      <Section kicker="Collaborations" title="Four collaborations, expanding with time.">
        <div className="grid gap-5 md:grid-cols-2">
          {collaborations.map((c) => (
            <Card key={c.title} title={c.focus} eyebrow={c.title}>
              {c.line}
            </Card>
          ))}
        </div>
      </Section>

      <Section kicker="Trainers" title="Built with coaches who live the work.">
        <div className="max-w-3xl text-sm leading-7 text-ink-900/80">
          For now, we’re launching with a tight circle of collaborators. Trainer profiles can expand here as you add names,
          bios, specialties, and availability.
        </div>
      </Section>
    </>
  )
}
