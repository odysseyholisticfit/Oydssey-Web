import { Container } from '@/components/Container'
import { ButtonLink } from '@/components/ButtonLink'

export default function ConsultPage() {
  const calendlyUrl = process.env.NEXT_PUBLIC_CALENDLY_URL

  return (
    <section className="py-14 sm:py-20">
      <Container>
        <div className="max-w-3xl">
          <div className="text-[0.72rem] tracking-[0.28em] uppercase text-ink-900/55">Consult</div>
          <h1 className="mt-3 font-serif text-3xl sm:text-4xl text-ink-900">Book a free intro consult.</h1>
          <p className="mt-4 text-sm leading-7 text-ink-900/80">
            Quick call to align your short-term and long-term path inside Odyssey.
          </p>

          {!calendlyUrl ? (
            <div className="mt-8 rounded-3xl bg-parchment-50/70 ring-1 ring-ink-900/10 p-6 shadow-soft">
              <div className="font-serif text-xl">Scheduler link not set yet.</div>
              <p className="mt-2 text-sm text-ink-900/75">
                Add <span className="font-mono">NEXT_PUBLIC_CALENDLY_URL</span> to your environment variables, and this
                page will embed your booking calendar.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <ButtonLink href="/request-access" variant="primary">
                  Request Access
                </ButtonLink>
                <ButtonLink href="/" variant="secondary">
                  Back Home
                </ButtonLink>
              </div>
            </div>
          ) : (
            <div className="mt-8 overflow-hidden rounded-3xl ring-1 ring-ink-900/10 shadow-soft">
              <iframe
                title="Book a consult"
                src={calendlyUrl}
                className="h-[760px] w-full"
                loading="lazy"
              />
            </div>
          )}
        </div>
      </Container>
    </section>
  )
}
