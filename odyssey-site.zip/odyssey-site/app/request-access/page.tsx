'use client'

import { useMemo, useState } from 'react'
import { ButtonLink } from '@/components/ButtonLink'
import { Container } from '@/components/Container'

type Status = 'idle' | 'submitting' | 'success' | 'error'

const goals = [
  'Longevity & mobility',
  'Strength foundation',
  'Athletic performance',
  'Recovery & restoration',
  'Holistic routine & consistency'
]

const levels = ['Beginner', 'Intermediate', 'Advanced', 'Professional']

const focuses = ['Yoga & Regulation', 'Strength & Foundation', 'Performance & Athletic Lab', 'Recovery & Restoration']

export default function RequestAccessPage() {
  const [status, setStatus] = useState<Status>('idle')
  const [error, setError] = useState<string>('')

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [goal, setGoal] = useState(goals[0])
  const [level, setLevel] = useState(levels[0])
  const [shortLong, setShortLong] = useState('')
  const [injuries, setInjuries] = useState('')
  const [focus, setFocus] = useState('')

  const canSubmit = useMemo(() => {
    return name.trim().length > 1 && /.+@.+\..+/.test(email) && shortLong.trim().length > 10
  }, [name, email, shortLong])

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!canSubmit) return

    setStatus('submitting')
    setError('')

    try {
      const res = await fetch('/api/request-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, goal, level, shortLong, injuries, focus })
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || 'Submission failed')
      }

      setStatus('success')
    } catch (err: any) {
      setStatus('error')
      setError(err?.message || 'Something went wrong')
    }
  }

  return (
    <section className="py-14 sm:py-20">
      <Container>
        <div className="max-w-2xl">
          <div className="text-[0.72rem] tracking-[0.28em] uppercase text-ink-900/55">Request Access</div>
          <h1 className="mt-3 font-serif text-3xl sm:text-4xl text-ink-900">Apply to enter Odyssey.</h1>
          <p className="mt-4 text-sm leading-7 text-ink-900/80">
            This helps us align you with the right path inside Odyssey.
          </p>

          {status === 'success' ? (
            <div className="mt-8 rounded-3xl bg-parchment-50/70 ring-1 ring-ink-900/10 p-6 shadow-soft">
              <div className="font-serif text-xl">Request received.</div>
              <p className="mt-2 text-sm text-ink-900/75">
                We’ll review your application and reach out with next steps. Stay ready.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <ButtonLink href="/" variant="secondary">
                  Back Home
                </ButtonLink>
                <ButtonLink href="/consult" variant="primary">
                  Book a Free Consult
                </ButtonLink>
              </div>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="mt-8 space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Full name</div>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                    placeholder="Your name"
                    autoComplete="name"
                  />
                </label>

                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Email</div>
                  <input
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                    placeholder="you@email.com"
                    autoComplete="email"
                    inputMode="email"
                  />
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Primary goal</div>
                  <select
                    value={goal}
                    onChange={(e) => setGoal(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                  >
                    {goals.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Experience level</div>
                  <select
                    value={level}
                    onChange={(e) => setLevel(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                  >
                    {levels.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="block">
                <div className="text-xs tracking-wide text-ink-900/70">
                  What are you looking for in the short term and long term?
                </div>
                <textarea
                  value={shortLong}
                  onChange={(e) => setShortLong(e.target.value)}
                  className="mt-2 w-full min-h-[140px] rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                  placeholder="Short term: ...\nLong term: ..."
                />
              </label>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Injuries or limitations (optional)</div>
                  <input
                    value={injuries}
                    onChange={(e) => setInjuries(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                    placeholder="Knee, shoulder, back…"
                  />
                </label>

                <label className="block">
                  <div className="text-xs tracking-wide text-ink-900/70">Preferred collaboration focus (optional)</div>
                  <select
                    value={focus}
                    onChange={(e) => setFocus(e.target.value)}
                    className="mt-2 w-full rounded-2xl bg-parchment-50 px-4 py-3 text-sm ring-1 ring-ink-900/15 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--ring))]"
                  >
                    <option value="">No preference</option>
                    {focuses.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              {status === 'error' ? (
                <div className="rounded-2xl bg-parchment-100 ring-1 ring-ink-900/10 p-4 text-sm text-ink-900">
                  {error}
                </div>
              ) : null}

              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <button
                  type="submit"
                  disabled={!canSubmit || status === 'submitting'}
                  className="inline-flex items-center justify-center rounded-full bg-ink-900 px-6 py-3 text-sm font-semibold text-parchment-50 shadow-soft transition hover:translate-y-[-1px] hover:shadow-ink disabled:opacity-50 disabled:hover:translate-y-0"
                >
                  {status === 'submitting' ? 'Submitting…' : 'Submit request'}
                </button>
                <div className="text-xs text-ink-900/60">
                  By submitting, you agree to be contacted about Odyssey access.
                </div>
              </div>
            </form>
          )}
        </div>
      </Container>
    </section>
  )
}
